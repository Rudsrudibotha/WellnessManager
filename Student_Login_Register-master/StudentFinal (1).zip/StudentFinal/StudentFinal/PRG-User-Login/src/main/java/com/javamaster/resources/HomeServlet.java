/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.javamaster.resources;

import com.javamaster.resources.exception.AuthException;     // Custom exception for authentication errors
import com.javamaster.resources.model.UsersModel;           // Model class for user data
import com.javamaster.resources.service.UserServiceImpl;    // Service class handling user-related logic
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * HomeServlet handles routing for the web application.
 * It processes login, registration, and main-page logic based on the URI.
 * @author glodi mukomo
 */
public class HomeServlet extends HttpServlet {
  /*
     * Common method that handles both GET and POST HTTP requests.
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the requested URI to determine which logic to execute
        String uri = request.getRequestURI();
        System.out.println(uri);                // Debug print to show which URI was hit
         // Route: /main-page
        if(uri.equals("/main-page")){
            
            // Check if the user is authenticated (session contains "user")
            if(request.getSession().getAttribute("user") == null){
                  // If not authenticated, show error page
                request.setAttribute("errorMessage", "User is not authenticated");
                request.getRequestDispatcher("/WEB-INF/view/error.jsp").forward(request, response);
            }
                // If authenticated, prepare a list of hardcoded users to display
            List<UsersModel> users = new ArrayList<>();
            users.add(new UsersModel("Glodi","mukomo29@gmail", 45));
            users.add(new UsersModel("Rudis","Rudis2@gmail", 35));
            users.add(new UsersModel("Abigail","Abigail25@gmail", 25));
            users.add(new UsersModel("Lolita","Lolita25@gmail", 15));
                // Read optional request parameter "userName" (likely for greeting)
            String userName = request.getParameter("userName");
             // Set request attributes to pass to the JSP
            request.setAttribute("users", users);
            request.setAttribute("welcomeMessage", "Hi user" + userName);
            
              // Forward to the main-page view (JSP)
            request.getRequestDispatcher("/WEB-INF/view/main-page.jsp").forward(request, response);
              // Route: /register
        }else if(uri.equals("/register")){
            String method = request.getMethod();
            System.out.println(method);
            
               // If GET, show the registration form
            if(method.equals("GET")){
                request.getRequestDispatcher("/WEB-INF/view/register.jsp").forward(request, response);
            }else{
                 // If POST, handle registration logic

                // Get form parameters
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String name = request.getParameter("name");
                System.out.println("Registering: " + email + ", " + password + ", " + name);
                
                // Register the user using the service class    
                //UserServiceImpl.getInstance().register(email, password, name);
                //response.sendRedirect("/login");
                UserServiceImpl.getInstance().register(email, password, name);
                
                // After successful registration, show the login page with a success message
                request.setAttribute("successMessage", "Registration successful. Please login.");
                request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);

            }
            
        }
         // Route: /login
        else if(uri.equals("/login")){
            String method = request.getMethod();
            
        // If GET, show the login form
            if(method.equals("GET")){
                request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);
            }else{
                 // If POST, handle login authentication
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                
                try {
                     // Try to authenticate the user
                    UsersModel user = UserServiceImpl.getInstance().auth(email, password);
                     // If successful, store user in session
                    HttpSession session = request.getSession();
                    session.setAttribute("user", user);
                     // Redirect to main page
                    response.sendRedirect("/main-page");
                } catch (AuthException ex) {
                      // If authentication fails, show error page with message
                    request.setAttribute("errorMessage", ex.getMessage());
                    request.getRequestDispatcher("/WEB-INF/view/error.jsp").forward(request, response);
                }
                
                
            }    
        }
        // Default route - show index.jsp if none of the above URIs matched
        else{
            request.getRequestDispatcher("/WEB-INF/view/index.jsp").forward(request, response);
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
