
package com.javamaster.resources.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * This class is responsible for providing a database connection
 * to a PostgreSQL database using JDBC.
 */
public class DBConnectionConfigs {
    
    public static Connection getConnection(){
        try {
             // Load the PostgreSQL JDBC driver class
            // This step ensures that the driver is registered with DriverManager
            try {
                Class.forName("org.postgresql.Driver");
            } catch (ClassNotFoundException ex) {
                 // Log error if driver class is not found
                Logger.getLogger(DBConnectionConfigs.class.getName()).log(Level.SEVERE, null, ex);
            }
            // Attempt to establish a connection to the PostgreSQL database
            // URL format: jdbc:postgresql://<host>:<port>/<database>
            // In this case: localhost on port 5432 to database "User-Login"
            return DriverManager.getConnection("jdbc:postgresql://localhost:5432/User-Login","postgres", "Ryan123");
        } catch (SQLException ex) {
            // Log any SQL connection errors
            Logger.getLogger(DBConnectionConfigs.class.getName()).log(Level.SEVERE, null, ex);
            
        }// Return null if connection fails
        return null;
    }/*
    public static Connection getConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/User-Login",
                "postgres",
                "Glodeson123"
            );
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }*/
}
